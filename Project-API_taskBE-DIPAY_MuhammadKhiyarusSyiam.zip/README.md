MUHAMMAD KHIYARUS SYIAM

HOW TO RUN : nodemon server.js

list api : 
Duplicate  Zero = [PoST] /duplicateZeros
Get Country = [GET] /api/v1/countries

Admin Login = [POST] /api/v1/admin/login
Get Employee by Company ID = [GET] /api/v1/companies/:id/employees
Get Employee by ID = [GET] /api/v1/employees/:id

Add Employee = [POST] /api/v1/employees/add
Update Employee = [PUT] /api/v1/employees/:id
Delete Employee = [DELETE] /api/v1/employees/:id

Add Company = [POST] /api/v1/companies/add
Get Companies = [GET] /api/v1/companies
Set Active = [PUT]/api/v1/companies/:id/set_active

